#include "APP_Key.h"

void APP_KEY_PRESS_STATE(u8 Address, u8 FUNC)	//������������һ��
{
    FUNC = FUNC;		//���ܸ���
//  Timer_SW_CMD(LED2_SW, 100, 0, 1, 1);
    switch (Address)
    {
        case KEY1_PRES:  //

        {
			if(!WAV_Mode())
			{
				WAV_CMD(ON);
			}
        }
        break;

        case KEY2_PRES://

        {
			if(!WAV_Mode())
			{
				WAV_CMD(BIT(7));
			}
        }
        break;

        case KEY3_PRES://

        {
			if(WAV_Mode())
			{
				WAV_CMD(OFF);
			}
        }
        break;
		
        case KEY4_PRES://

        {
			if(!WAV_Mode())
				VS1003_SineTest();//���Ҳ�����
        }
        break;

        case KEY5_PRES://

        {
			if(!WAV_Mode())
				printf("VS1003 RAM :%#x \r\n",VS1003_RamTest());//RAM����
        }
        break;
    }
}

void APP_KEY_LINK_STATE(u8 Address, u8 MAX_Len) //�����Ͽ�����һ�� (���126����)
{

    switch (Address)
    {
        case KEY1_PRES:  //

        {

        }
        break;

        case KEY2_PRES://

        {

        }
        break;

        case KEY3_PRES://

        {

        }
        break;
		
        case KEY4_PRES://

        {

        }
        break;

        case KEY5_PRES://

        {

        }
        break;
    }
}

void APP_KEY_LONG_STATE(u8 Address, u8 FUNC)	//��������һ��
{
    FUNC = FUNC;		//���ܸ���

    switch (Address)
    {
        case KEY1_PRES:  //

        {

        }
        break;

        case KEY2_PRES://

        {

        }
        break;

        case KEY3_PRES://

        {

        }
        break;
		
        case KEY4_PRES://

        {

        }
        break;

        case KEY5_PRES://

        {

        }
        break;
    }
}

void APP_KEY_INTERVAL_STATE(u8 Address, u8 FUNC)//����ѭ����϶����һ��
{
    FUNC = FUNC;		//���ܸ���

    switch (Address)
    {
        case KEY1_PRES:  //

        {

        }
        break;

        case KEY2_PRES://

        {

        }
        break;

        case KEY3_PRES://

        {

        }
        break;
		
        case KEY4_PRES://

        {

        }
        break;

        case KEY5_PRES://

        {

        }
        break;
    }
}

void APP_KEY_RELEASE_STATE(u8 Address, u8 FUNC)	//�ɿ�����һ��
{
    FUNC = FUNC;		//���ܸ���

    switch (Address)
    {
        case KEY1_PRES:  //

        {

        }
        break;

        case KEY2_PRES://

        {

        }
        break;

        case KEY3_PRES://

        {

        }
        break;
		
        case KEY4_PRES://

        {

        }
        break;

        case KEY5_PRES://

        {

        }
        break;
    }
}


void APP_KEY_ON_STATE(u8 Address, u8 FUNC)		//����һֱ����
{
    FUNC = FUNC;		//���ܸ���

    switch (Address)
    {
        case KEY1_PRES:  //

        {

        }
        break;

        case KEY2_PRES://

        {

        }
        break;

        case KEY3_PRES://

        {

        }
        break;
		
        case KEY4_PRES://

        {

        }
        break;

        case KEY5_PRES://

        {

        }
        break;
    }
}

void APP_KEY_Init(void)						//������ʼ��
{
    Key_Init(&User.Mode, &User.Function);		//������ʼ��
    Key_TaskBuild(APP_KEY_PRESS_STATE, APP_KEY_LINK_STATE, APP_KEY_LONG_STATE, \
                  APP_KEY_INTERVAL_STATE, APP_KEY_RELEASE_STATE, APP_KEY_ON_STATE	);//��������ע��
}
