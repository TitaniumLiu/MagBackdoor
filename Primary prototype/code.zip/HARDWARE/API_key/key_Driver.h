#ifndef key_Driver_H
#define key_Driver_H

#include "main.h"

#define ACT_KEY_N		5

void key_Driver_Init(void);
u32 key_Driver_Read(void);
u32 key_Driver_Run(void);

#endif
