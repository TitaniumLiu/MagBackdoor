#ifndef __APP_Key_H_
#define __APP_Key_H_

#include "main.h"

//****************���а���****************//
enum
{
    KEY1_PRES      	= 0,//
    KEY2_PRES,       	//
    KEY3_PRES,   		//
	KEY4_PRES,   		//
	KEY5_PRES,   		//
};

void APP_KEY_Init(void);

#endif
