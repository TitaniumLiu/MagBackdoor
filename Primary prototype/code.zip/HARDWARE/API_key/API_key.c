/*
 * @Author: LYF  、 Zhang
 * @Date: 2021-09-18 16:14:40
 * @LastEditors: LYF 、 Zhang
 * @LastEditTime: 2022-02-08 13:16:28
 * @Description:  按键扫描处理
 * @FilePath: \undefinedd:\Code\ALL_SDK\SDK\4.API\KEY\API_key.c
 */
#include "API_key.h"

u16 g_Key_Time[KEY_MAX];//按键计时变量
u8 g_Key_Data[KEY_MAX];	//按键状态变量

u32 g_Key_Value = 0;	//按键值
u16 g_Key_Run_Time = 0;	//按键运行时间

void (*Key_APP_Task[6])(u8, u8) = { NULL }; //APP执行函数

extern u16  code c_Key_LongTime[KEY_MAX];
extern u16  code c_Key_LongProcessTime[KEY_MAX];

u8 STEP_MODE = 0;	//上一次模式

u8 *KEY_FUNC;	//功能选择
u8 *MODE_DATA;	//当前模式

/*****************************************************************************
函数名称 : KEY_Init
功能描述 : KEY初始化服务函数
输入参数 :	Mode		当前状态模式
			Function	当前功能状态
返回参数 : void
使用说明 : 初始化调用
*****************************************************************************/
void Key_Init(u8 *Mode, u8 *Function)
{
    u8 i = 0;

    for (i = 0; i < KEY_MAX; i++)
    {
        g_Key_Time[i] = 0;
        g_Key_Data[i] = 0;
    }

    g_Key_Value = 0;
    KEY_Drive_Init;
    Key_Read(0);

    MODE_DATA = Mode;
    KEY_FUNC = Function;
}

/*****************************************************************************
函数名称 : Key_TaskBuild
功能描述 : KEY执行函数注册
输入参数 :	Key_Task0：按下立即触发一次
			Key_Task1：连击断开触发一次 (最大126连击)
			Key_Task2：长按触发一次
			Key_Task3：长按循环间隙触发一次
			Key_Task4：松开触发一次
			Key_Task5：按下一直触发
返回参数 : void
使用说明 : 初始化调用
*****************************************************************************/
void Key_TaskBuild(void (*Key_Task0)(u8, u8), void (*Key_Task1)(u8, u8), void (*Key_Task2)(u8, u8), void (*Key_Task3)(u8, u8), void (*Key_Task4)(u8, u8), void (*Key_Task5)(u8, u8))
{
    Key_APP_Task[0] = Key_Task0;
    Key_APP_Task[1] = Key_Task1;
    Key_APP_Task[2] = Key_Task2;
    Key_APP_Task[3] = Key_Task3;
    Key_APP_Task[4] = Key_Task4;
    Key_APP_Task[5] = Key_Task5;
}

/*****************************************************************************
函数名称 : KEY_TimerPlus
功能描述 : KEY基准时间累加
输入参数 : void
返回参数 : void
使用说明 : 定时器调用，调用一次，基准时间加1
*****************************************************************************/
void Key_Timer(void)
{
    u8 i = 0;

    for (i = 0; i < KEY_MAX; i++)
    {
        g_Key_Time[i]++;

        if (!BIT_READ(g_Key_Value, i))	//按键位置数据扫描更新
            g_Key_Time[i] = 0;
    }
}

/*****************************************************************************
函数名称 : Key_Run
功能描述 : 按键数据更新
输入参数 : void
返回参数 : void
使用说明 : 循环调用
*****************************************************************************/
void Key_Run(void)
{
	u8 state;
	
    if (Tick_ms(Min[Key_Run_Time]) <= 3)//5ms更新一次
        return;
    Tick_Clear(&Min[Key_Run_Time]);
	
    KEY_Drive_Run;				//按键状态刷新
    g_Key_Value = KEY_TRIGGER;	//按键值获取

    for (state = 0; state < KEY_MAX; state++)
    {
        if (BIT_READ(g_Key_Value, state))	//按键位置数据扫描更新
        {
            if (g_Key_Time[state] >= (c_Key_LongTime[state] + \
                                      c_Key_LongProcessTime[state]))
            {
                g_Key_Data[state] = KEY_INTERVAL_STATE;	//按键长按过程状态
                g_Key_Time[state] = c_Key_LongTime[state];
            }

            else if (g_Key_Time[state] >= c_Key_LongTime[state])
            {
                g_Key_Data[state] = KEY_LONG_STATE;		//按键长按开始状态
            }

            else if (g_Key_Time[state] >= Key_DelayTime)
            {
                g_Key_Data[state] = KEY_PRESS_STATE;		//按键按下状态
            }

            else
            {
                g_Key_Data[state] = KEY_IDLE_STATE;		//按键空闲状态
            }
        }

        else
        {
            if (g_Key_Data[state] > KEY_RELEASE_STATE)
            {
                g_Key_Data[state] = KEY_RELEASE_STATE;		//按键松开状态
            }

            else if (g_Key_Data[state] > KEY_IDLE_STATE)
            {
                g_Key_Data[state] = KEY_IDLE_STATE;		//按键空闲状态
            }
        }
    }
}

/*****************************************************************************
函数名称 : Key_Task
功能描述 : 按键任务运行
输入参数 : void
返回参数 : void
使用说明 : 循环调用
*****************************************************************************/
u8* Key_Task(void)
{
    static u8 IP[2], Key_Link = 0xFF, MAX_Len = 0;
    static u8 key = 0, s_Step_Last = 0;//上一次运行的步骤
	static bit STEP_MODE_Bit=ON;
    u8 state;       					//这一次缓存

    for (state = 0; state < 6; state++)//任务注册检测
    {
        if (Key_APP_Task[state] == NULL)
            return &IP[0];
    }
	
	Key_Run();
	
    state = Key_Read(key);       	//这一次
    IP[1] = key;					//按键地址
    IP[0] = state;					//按键状态

    if (state)                		//按键状态
    {
        if (state > KEY_RELEASE_STATE)
            Key_APP_Task[5](KEY(key), *KEY_FUNC);				//按下一直执行

        if (STEP_MODE == *MODE_DATA)	//不保留上一次状态
        {
			STEP_MODE_Bit=ON;
            if ((state == KEY_INTERVAL_STATE) && (s_Step_Last == (KEY_LONG_STATE + KEY(key) * KEY_MODE_MAX))) //间隙
            {
                s_Step_Last = KEY_INTERVAL_STATE + KEY(key) * KEY_MODE_MAX;
                Key_APP_Task[3](KEY(key), *KEY_FUNC);			//按键间隙执行函数
            }

            else if (state == KEY_LONG_STATE) //长按
            {
                if (s_Step_Last == (KEY_PRESS_STATE + KEY(key) * KEY_MODE_MAX))
                {
                    Key_APP_Task[2](KEY(key), *KEY_FUNC);		//按键长按执行函数
                }

                s_Step_Last = KEY_LONG_STATE + KEY(key) * KEY_MODE_MAX;
            }

            else if (s_Step_Last < KEY_RELEASE_STATE) //按下
            {
                s_Step_Last = KEY_PRESS_STATE + KEY(key) * KEY_MODE_MAX;

				if ((Key_Link & 0x7F) == KEY(key))
				{
					if ((Tick_ms(Min[Key_Last_Time]) < LAST_KEY_TIME))
					{
						Tick_Clear(&Min[Key_Last_Time]);
						MAX_Len++;
						Key_Link = Key_Link | 0x80;
					}
				}

				else
				{
					Key_Link = KEY(key);
					MAX_Len = 1;
					Tick_Clear(&Min[Key_Last_Time]);
				}

                Key_APP_Task[0](KEY(key), *KEY_FUNC);			//按键按下执行函数
            }

            else if ((state == KEY_RELEASE_STATE) && (s_Step_Last > KEY_RELEASE_STATE + KEY(key) * KEY_MODE_MAX)) //松开
            {
                s_Step_Last = KEY_RELEASE_STATE + KEY(key) * KEY_MODE_MAX;

                Key_APP_Task[4](KEY(key), *KEY_FUNC);			//按键松开执行函数
            }
        }
		else
			STEP_MODE_Bit=OFF;
    }

    else
    {
        if (Tick_ms(Min[Key_Last_Time]) >= LAST_KEY_TIME)
        {
            if (Key_Link != 0xFF)
            {
				if(STEP_MODE_Bit)
					Key_APP_Task[1](Key_Link & 0x7F, MAX_Len);			//按键连击执行函数
                MAX_Len = 0;
            }

            Key_Link = 0xFF;
            Min[Key_Last_Time] = Tick_sys() - LAST_KEY_TIME;
        }

        STEP_MODE = *MODE_DATA;
        s_Step_Last = 0;

        if (++key >= KEY_MAX)key = 0; //按键扫描
    }

    return &IP[0];
}

/*****************************************************************************
函数名称 : KEY_Read
功能描述 : 获取KEY状态值
输入参数 : Key_Addr：按键地址
返回参数 : 按键当前状态
使用说明 : 读取调用
*****************************************************************************/
u8 Key_Read(u8 Addr)
{
    u8 Result = 0;

    if (Addr < KEY_MAX)
    {
        Result = g_Key_Data[Addr];
    }

    return Result;
}

u16 code c_Key_LongTime[KEY_MAX] =
{
#if	KEY_MAX > 0
    KEY0_LONGPRESS_TIME
#endif
#if	KEY_MAX > 1
    , KEY1_LONGPRESS_TIME
#endif
#if	KEY_MAX > 2
    , KEY2_LONGPRESS_TIME
#endif
#if	KEY_MAX > 3
    , KEY3_LONGPRESS_TIME
#endif
#if	KEY_MAX > 4
    , KEY4_LONGPRESS_TIME
#endif
#if	KEY_MAX > 5
    , KEY5_LONGPRESS_TIME
#endif
#if	KEY_MAX > 6
    , KEY6_LONGPRESS_TIME
#endif
#if	KEY_MAX > 7
    , KEY7_LONGPRESS_TIME
#endif
#if	KEY_MAX > 8
    , KEY8_LONGPRESS_TIME
#endif
#if	KEY_MAX > 9
    , KEY9_LONGPRESS_TIME
#endif
#if	KEY_MAX > 10
    , KEY10_LONGPRESS_TIME
#endif
#if	KEY_MAX > 11
    , KEY11_LONGPRESS_TIME
#endif
#if	KEY_MAX > 12
    , KEY12_LONGPRESS_TIME
#endif
#if	KEY_MAX > 13
    , KEY13_LONGPRESS_TIME
#endif
#if	KEY_MAX > 14
    , KEY0_LONGPRESS_TIME
#endif
#if	KEY_MAX > 15
    , KEY14_LONGPRESS_TIME
#endif
#if	KEY_MAX > 16
    , KEY15_LONGPRESS_TIME
#endif
#if	KEY_MAX > 17
    , KEY16_LONGPRESS_TIME
#endif
#if	KEY_MAX > 18
    , KEY17_LONGPRESS_TIME
#endif
#if	KEY_MAX > 19
    , KEY19_LONGPRESS_TIME
#endif
#if	KEY_MAX > 20
    , KEY20_LONGPRESS_TIME
#endif
};

u16 code c_Key_LongProcessTime[KEY_MAX] =
{
#if	KEY_MAX > 0
    KEY0_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 1
    , KEY1_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 2
    , KEY2_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 3
    , KEY3_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 4
    , KEY4_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 5
    , KEY5_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 6
    , KEY6_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 7
    , KEY7_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 8
    , KEY8_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 9
    , KEY9_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 10
    , KEY10_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 11
    , KEY11_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 12
    , KEY12_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 13
    , KEY13_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 14
    , KEY14_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 15
    , KEY15_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 16
    , KEY16_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 17
    , KEY17_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 18
    , KEY18_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 19
    , KEY19_LONG_PROCESS_TIME
#endif
#if	KEY_MAX > 20
    , KEY20_LONG_PROCESS_TIME
#endif
};

