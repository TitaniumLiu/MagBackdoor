/*
 * @Author: LYF
 * @Date: 2021-09-18 16:14:40
 * @LastEditors: LYF
 * @LastEditTime: 2022-02-08 13:19:51
 * @Description:  按键扫描处理
 * @FilePath: \undefinedd:\Code\ALL_SDK\ALIENTEK MINISTM32RTC\HARDWARE\KEY\key_Driver.c
 */
#include "key_Driver.h"

bit32 g_Touch_Data = {0};

/*****************************************************************************
函数名称 : Touch_ReadData
功能描述 : KEY初始化服务函数
输入参数 : void
返回参数 : void
使用说明 : 初始化调用
*****************************************************************************/
void key_Driver_Init(void)
{
    GPIO_InitTypeDef GPIO_InitStructure;

    RCC_APB2PeriphClockCmd( RCC_APB2Periph_GPIOC, ENABLE);
	
    GPIO_InitStructure.GPIO_Pin = GPIO_Pin_8 | GPIO_Pin_9 | GPIO_Pin_10 | GPIO_Pin_11 | GPIO_Pin_12;
    GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
    GPIO_InitStructure.GPIO_Mode = GPIO_Mode_IPU;
    GPIO_Init(GPIOC, &GPIO_InitStructure);

}

/*****************************************************************************
函数名称 : key_Driver_Read
功能描述 : KEY初始化服务函数
输入参数 : void
返回参数 : void
使用说明 : 初始化调用
*****************************************************************************/
u32 key_Driver_Read(void)
{
    return g_Touch_Data.DATA;
}

u32 key_Driver_Run(void)
{
    g_Touch_Data.Data.Bit0 = !PCin(8);
    g_Touch_Data.Data.Bit1 = !PCin(9);
    g_Touch_Data.Data.Bit2 = !PCin(10);
	g_Touch_Data.Data.Bit3 = !PCin(11);
	g_Touch_Data.Data.Bit4 = !PCin(12);

    return g_Touch_Data.DATA;
}
