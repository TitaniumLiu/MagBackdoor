#ifndef __WAV_H
#define __WAV_H

#include "sys.h"

u8 WAV_CMD(u8 SW);
void WAV_Run(void);
u8 WAV_Mode(void);

#endif





