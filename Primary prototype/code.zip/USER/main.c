#include "main.h"

int main(void)
{
    delay_init();	    	 //��ʱ������ʼ��
    uart_init(115200);	 	//���ڳ�ʼ��Ϊ115200

    LCD_Init();//LCD��ʼ��
    LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
    LED_Init();
    LED1 = 1;
    LED0 = 1;
    delay_ms(100);
    TIM3_Int_Init(720 - 1, 100 - 1);
    APP_KEY_Init();

    printf("STM32\r\n");

    VS1003_Init();		//VS1003�˿ڳ�ʼ��
    VS1003_Reset();		//VS1003��λ
    VS1003_SoftReset();	//VS1003����λ

    delay_ms(100);							//��ʱ

    printf("txt:OK\r\n");

    Tick_Clear(&Min[main_Time]);

    while (1)
    {
        if (WAV_Mode())
        {
            Tick_Clear(&Min[main_Time]);
        }
        else if (Tick_ms(Min[main_Time]) >= 1000)
        {
            Tick_Clear(&Min[main_Time]);

            LCD_ShowString(10, 15, "KEY1: Start-1", BLUE, WHITE, 16, 0);
            LCD_ShowString(10, 35, "KEY2: Start-2", GRED, WHITE, 16, 0);
			LCD_ShowString(10, 55, "KEY3: End", GBLUE, WHITE, 16, 0);
        }
        WAV_Run();
        User_Run();
    }
}
