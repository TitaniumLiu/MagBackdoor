#ifndef __MAIN_H
#define __MAIN_H

#include "string.h"

#include "sys.h"
#include "delay.h"
#include "usart.h"


#include "led.h"
#include "ch375.h"
#include "znfat.h"
#include "vs1003.h"
#include "Tick_Time.h"
#include "timer.h"

#include "lcd_init.h"
#include "lcd.h"

#include "wav.h"
#include "API_key.h"
#include "user.h"

#endif
