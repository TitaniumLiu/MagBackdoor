#include "delay.h"
#include "sys.h"
#include "usart.h"
#include "ch375.h"
#include "znfat.h"
#include "vs1003.h"
#include "Tick_Time.h"
#include "timer.h"
#include "string.h"

//#include "lcd_init.h"
#include "lcd.h"
//#include "pic.h"
#include "led.h"
#include "Tick_Time.h"

u8 WAV_SW = OFF;
u16 MAW_Time = 0;

u8 WAV_Mode(void)
{
    return WAV_SW;
}

/******************************************************************
 - ������������һ��32λ�ı���datתΪ�ַ����������1234תΪ"1234"
 - ����ģ�飺��������ģ��
 - �������ԣ��ⲿ���û��ɵ���
 - ����˵����dat:��ת��long�͵ı���
             str:ָ���ַ������ָ�룬ת������ֽڴ���������
 - ����˵������
 ******************************************************************/

void u32tostr(u32 dat, char *str)
{
    char temp[20];
    u8 i = 0, j = 0;
    i = 0;
    while (dat)
    {
        temp[i] = dat % 10 + 0x30;
        i++;
        dat /= 10;
    }
    j = i;
    for (i = 0; i < j; i++)
    {
        str[i] = temp[j - i - 1];
    }
    if (!i)
    {
        str[i++] = '0';
    }
    str[i] = 0;
}


struct znFAT_Init_Args Init_Args; //��ʼ��TF����������
struct FileInfo fileinfo; //�ļ���Ϣ����
struct DateTime dt; //������ʱ��

u8 wav_dat[512] = {0};
char wav_fn[20] = {'/', 'T', 'a', 'p', 'e', '_', '0', '0', '0', '\0'};
u32 nfn = 0;

u16 blockNumber = 0, temp = 0, i = 0, counter = 0;
u32 sectorCount = 1, SEC_CAL = 0;

/** first part of RIFF Header, insert 444 zeroes after this */
u8 RIFFHeader0[52] =
{
    'R', 'I', 'F', 'F',     // Chunk ID (RIFF)
    0x70, 0x70, 0x70, 0x70, // Chunk payload size (calculate after rec!)
    'W', 'A', 'V', 'E',     // RIFF resource format type
    'f', 'm', 't', ' ',     // Chunk ID (fmt )
    0x14, 0x00, 0x00, 0x00, // Chunk payload size (0x14 = 20 bytes)
    0x11, 0x00,             // Format Tag (IMA ADPCM)
    0x01, 0x00,             // Channels (1)
    0x40, 0x1f, 0x00, 0x00, // Sample Rate, 0x1f40 = 8.0kHz
    0xd7, 0x0f, 0x00, 0x00, // Average Bytes Per Second
    0x00, 0x01,             // Data Block Size (256 bytes)
    0x04, 0x00,             // ADPCM encoded bits per sample (4 bits)
    0x02, 0x00,             // Extra data (2 bytes)
    0xf9, 0x01,             // Samples per Block (505 samples)
    'f', 'a', 'c', 't',     // Chunk ID (fact)
    0xc8, 0x01, 0x00, 0x00, // Chunk payload size (456 bytes (zeropad!))
    0xff, 0xff, 0xff, 0xff  // Number of Samples (calculate after rec!)
};                       // Insert 448 zeroes here!

//add 452 zeros after

u8  RIFFHeader504[8] = {'d', 'a', 't', 'a',     // Chunk ID (data)
                        0x70, 0x70, 0x70, 0x70  // Chunk payload size (calculate after rec!)
                       };

u8 CH375_Data_Init(void)
{
    u8 i = 0;

    if (!CH375Init())
    {
        BIT_ON(i, 0);
        printf("\r\n\r\nCH375��ʼ���ɹ�\n");
    }
    else
    {
        BIT_OFF(i, 0);
        printf("\r\n\r\nCH375��ʼ��ʧ��\n");
    }

    if (0 == znFAT_Device_Init())	//�洢�豸��ʼ��
    {
        BIT_ON(i, 1);
        printf("U�̳�ʼ���ɹ�\r\n");
    }

    else
    {
        BIT_OFF(i, 1);
        printf("U�̳�ʼ��ʧ��\r\n");
    }

    if (i >= (BIT(1) | BIT(0)))
        znFAT_Select_Device(0, &Init_Args); //ѡ���豸0��Ҳ�����ҵ�U��

    delay_ms(200);
    if (i >= (BIT(1) | BIT(0)))
    {
        if (!znFAT_Init())
        {
            BIT_ON(i, 2);
            printf("�ļ�ϵͳ��ʼ���ɹ�\r\n"); //�ļ�ϵͳ��ʼ��
        }
        else
        {
            BIT_OFF(i, 2);
            printf("�ļ�ϵͳ��ʼ��ʧ��\r\n");
        }
        delay_ms(100);							//��ʱ
    }
    else
    {
        i = 0;
        delay_ms(500);
    }

    return i;
}

u8 WAV_CMD(u8 SW)
{
    u32 res = 0, len = 0;
    static u16 i = 0;

    if (SW)
        WAV_SW = ON;
    else
    {
        WAV_SW = OFF;
        return WAV_SW;
    }
	
	VS1003_SoftReset();
	VS1003_Reset();			//VS1003��λ
	
    LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
    LCD_ShowString(40, 2, "disk...", RED, WHITE, 16, 0);
    while (CH375_Data_Init() != _0000_0111);
    LCD_ShowString(40, 2, "disk_OK", RED, WHITE, 16, 0);

	if(BIT_READ(SW,7))
		VS1003_Record_Init();//VS1003¼����ʼ�� ������
	else
		VS1003_LineIn_Init();//��������¼��

    delay_ms(10);							//��ʱ
    dt.date.year = 2022;
    dt.date.month = 03;
    dt.date.day = 12;
    dt.time.hour = 15;
    dt.time.min = 14;
    dt.time.sec = 35;

    while (VS1003_ReadReg(SPI_HDAT1) >> 8); //�Ȱѻ������е����ݶ���

WAV_INIT:
    u32tostr(nfn, wav_fn + 8); //�Ѽ���ֵתΪ�ַ�����Ϊ�˺ϳ�WAV�ļ����ļ���
    len = strlen(wav_fn);
    strcpy(wav_fn + len, ".WAV"); //�ϳ��µ��ļ���
    nfn++;

    res = znFAT_Create_File(&fileinfo, wav_fn, &dt); //����WAV�ļ�

    if (!res) //�����ļ��ɹ�
    {
        LCD_ShowString(10, 20, "OK ", RED, WHITE, 16, 0);
        printf("����WAV�ļ��ɹ�\r\n");
        LED0 = 0;
    }
    else
    {
        LCD_ShowString(10, 20, "-->", RED, WHITE, 16, 0);
        printf("����WAV�ļ�ʧ��\r\n");
        LED0 = 1;
        i++;
        wav_fn[6] = i / 100 % 10 + '0';
        wav_fn[7] = i / 10 % 10 + '0';
        wav_fn[8] = i % 10 + '0';
        goto WAV_INIT;
    }
    LCD_ShowString(20, 2, (u8 *)wav_fn, RED, WHITE, 16, 0);
    znFAT_WriteData(&fileinfo, 512, wav_dat); //��RIFFͷд���ļ�����Ч����
    LCD_ShowString(10, 40, "...", RED, WHITE, 16, 0);
    printf("¼�ƿ�ʼ\r\n");
    LED1 = 0;
    Tick_Clear(&MAW_Time);
    return WAV_SW;
}

void WAV_Run(void)
{
    static u8 WAV_Mode = OFF;
    char Time[20];
    static u32 Time_S = 1;

    if (WAV_SW)
    {
        WAV_Mode = ON;

        if (Tick_ms(MAW_Time) >= 1000)
        {
            Tick_Clear(&MAW_Time);
            sprintf(Time, "%02u:%02u", Time_S / 60 % 60, Time_S % 60);
            Time_S++;
            LCD_ShowString(100, 40, (u8 *)Time, RED, WHITE, 16, 0);
        }
        if (VS1003_ReadReg(SPI_HDAT1) >= 128)
        {
            for (i = 0; i < 128; i++)
            {
                temp = VS1003_ReadReg(SPI_HDAT0);
                wav_dat[counter++] = (unsigned char)(temp >> 8);
                wav_dat[counter++] = (unsigned char)(temp & 0xff);
            }
            blockNumber++;
        }

        if (blockNumber == 2) //��512�ֽ�дһ��
        {
            blockNumber = 0;
            counter = 0;

            sectorCount++;
            znFAT_WriteData(&fileinfo, 512, wav_dat); //��WAV����д���ļ�
        }
    }
    else if (WAV_Mode)
    {
        WAV_Mode = OFF;
        Time_S = 0;
        Tick_Clear(&MAW_Time);
        //ƴ��RIFF����
        for (i = 0; i < 56; i++)
        {
            wav_dat[i] = RIFFHeader0[i];
        }
        for (i = 52; i < 504; i++)
        {
            wav_dat[i] = 0;
        }
        for (i = 504; i < 512; i++)
        {
            wav_dat[i] = RIFFHeader504[i - 504];
        }

        SEC_CAL = (sectorCount - 1) * 1010;
        wav_dat[48] = (SEC_CAL & 0xff);
        wav_dat[49] = ((SEC_CAL >> 8) & 0xff);
        wav_dat[50] = ((SEC_CAL >> 16) & 0xff);
        wav_dat[51] = ((SEC_CAL >> 24) & 0xff);

        SEC_CAL = (sectorCount * 512) - 8; //�ܳ���,RIFF���(����wav�ļ���С-8)
        wav_dat[4] = (SEC_CAL & 0xff);
        wav_dat[5] = ((SEC_CAL >> 8) & 0xff);
        wav_dat[6] = ((SEC_CAL >> 16) & 0xff);
        wav_dat[7] = ((SEC_CAL >> 24) & 0xff);

        SEC_CAL = (sectorCount - 1) * 512; //��ʵ¼�����ݴ�С,Data���
        wav_dat[508] = (SEC_CAL & 0xff);
        wav_dat[509] = ((SEC_CAL >> 8) & 0xff);
        wav_dat[510] = ((SEC_CAL >> 16) & 0xff);
        wav_dat[511] = ((SEC_CAL >> 24) & 0xff);

        znFAT_Modify_Data(&fileinfo, 0, 512, wav_dat); //��WAV�ļ��е�RIFF�����޸�Ϊʵ����Ч��RIFFͷ����

        znFAT_Close_File(&fileinfo);
        znFAT_Flush_FS();
        sectorCount = 1;

        VS1003_SoftReset();
        VS1003_Reset();			//VS1003��λ
        printf("MAV¼�ƽ���-OK \r\n\r\n");
        LED1 = 1;
        LED0 = 1;
        LCD_ShowString(10, 40, "OK ", RED, WHITE, 16, 0);
    }

    if (!WAV_SW)
    {
        if (Time_S == 0)
        {
            if (Tick_ms(MAW_Time) >= 800)
            {
                Tick_Clear(&MAW_Time);
                LCD_Fill(0, 0, LCD_W, LCD_H, WHITE);
                Time_S = 1;
            }
        }
    }
}
